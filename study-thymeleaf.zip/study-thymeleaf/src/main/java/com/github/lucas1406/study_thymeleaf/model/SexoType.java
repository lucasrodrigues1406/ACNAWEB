package com.github.lucas1406.study_thymeleaf.model;

public enum SexoType {
      F, M;
}
